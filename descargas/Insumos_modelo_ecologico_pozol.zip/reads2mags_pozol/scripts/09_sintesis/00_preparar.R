# PREPARACION COMUN — visible en la practica.
# Cada figura inicia una sesion R y vuelve a leer estos insumos pequenos.
# No instala paquetes, no usa internet, no remuestrea ni ejecuta pruebas.
# Graficos: ggplot2. Diversidad: diversity() de vegan.
# t(p) coloca muestras en filas, como requieren las funciones de vegan.

library(ggplot2)
library(vegan)
Sys.setenv(OMP_NUM_THREADS = "1", OPENBLAS_NUM_THREADS = "1")
dir.create("results/09_sintesis", showWarnings = FALSE)
tiempos <- c("0", "9", "24", "48")
horas <- as.numeric(tiempos)
etiquetas <- paste(tiempos, "h")
# Paletas compartidas: el mismo significado conserva siempre el mismo color.
colores_h <- c("0" = "#395F9E", "9" = "#D9A044", "24" = "#087F8C", "48" = "#9756A5")
colores_tiempo <- setNames(unname(colores_h), etiquetas)
colores_datos <- c(Kraken = "#087F8C", Kaiju = "#9756A5", Funciones = "#BE8125")
colores_estado <- c("Anotado" = "#087F8C", "Asignación múltiple" = "#C59BD0", "No recuperado" = "#E8ECEF")
theme_set(theme_minimal(base_size = 16))
theme_update(plot.title = element_text(face = "bold", size = 22, colour = "#173B4D"),
             plot.subtitle = element_text(size = 14, colour = "#50616B"),
             plot.caption = element_text(size = 12, hjust = 0, colour = "#50616B"),
             axis.title = element_text(size = 16),
             axis.text = element_text(size = 14, colour = "#263D48"),
             legend.text = element_text(size = 13),
             plot.title.position = "plot", plot.caption.position = "plot",
             panel.grid.minor = element_blank(),
             plot.margin = margin(20, 24, 20, 20), legend.position = "bottom")

# 1. LEER CONTEOS DE GENEROS BACTERIANOS Y DENOMINADORES.
# Cada fila es un TaxID de rango G; no se sumaron ancestros y descendientes.
tabla <- read.delim("data/09_sintesis/generos_conteos.tsv", check.names = FALSE)
den <- read.delim("data/09_sintesis/denominadores.tsv", check.names = FALSE)
den <- den[match(horas, den$time_h), ]
conteos <- as.matrix(tabla[, tiempos])
rownames(conteos) <- as.character(tabla$taxid)
stopifnot(!anyNA(conteos), !anyNA(den), all(conteos >= 0),
          !anyDuplicated(tabla$taxid), all(colSums(conteos) == den$bacteria_genus))

# 2. DOS DENOMINADORES: NO SON INTERCAMBIABLES.
# Porcentaje del TOTAL de fragmentos, para composicion y cambios.
porcentaje <- sweep(conteos, 2, den$total_fragments, "/") * 100
# Proporcion DENTRO de los generos bacterianos, para diversidad.
p <- sweep(conteos, 2, colSums(conteos), "/")
write.table(data.frame(TaxID = tabla$taxid, Genero = tabla$name, porcentaje,
                       check.names = FALSE),
            "results/09_sintesis/01_porcentajes_generos.tsv", sep = "\t", row.names = FALSE, quote = FALSE)

# Cambios en puntos porcentuales respecto al TOTAL de fragmentos.
# Se guardan por separado de los cambios dentro del perfil usados en la figura 4.
cambios_total <- porcentaje[, 2:4, drop = FALSE] - porcentaje[, 1:3, drop = FALSE]
colnames(cambios_total) <- c("0_a_9_h", "9_a_24_h", "24_a_48_h")
write.table(data.frame(TaxID = tabla$taxid, Genero = tabla$name, cambios_total),
            "results/09_sintesis/02_cambios_pp.tsv", sep = "\t", row.names = FALSE, quote = FALSE)

source("scripts/09_sintesis/00_preparar.R", encoding = "UTF-8")
library(patchwork)
# Diversidad sobre proporciones originales: no CLR ni pseudoconteos.
k <- read.delim("data/09_sintesis/kaiju_matrix.tsv", check.names = FALSE)
k <- k[k$Taxonomy != "unclassified", ]
kaiju <- t(as.matrix(k[, c("0hrs", "9hrs", "24hrs", "48hrs")]))
mag <- as.matrix(read.delim("data/09_sintesis/MAG_KO_conteos.tsv", row.names = 1, check.names = FALSE))
meta <- read.delim("data/09_sintesis/MAG_metadata.tsv", check.names = FALSE)
stopifnot(!anyDuplicated(meta$MAG), setequal(rownames(mag), meta$MAG))
meta <- meta[match(rownames(mag), meta$MAG), ]
# Un índice por muestra (lecturas) o por MAG (funciones).
# vegan::diversity convierte los conteos a proporciones dentro de cada fila.
matrices <- list(Kraken = t(conteos), Kaiju = kaiju, Funciones = mag)
individuales <- list()
for (tipo in names(matrices)) {
  x <- matrices[[tipo]]
  t <- if (tipo == "Funciones") meta$Tiempo_h else horas
  individuales[[tipo]] <- data.frame(Tipo = tipo, ID = if (tipo == "Funciones") rownames(mag) else etiquetas,
    Tiempo_h = t, q1 = exp(vegan::diversity(x, index = "shannon")),
    q2 = vegan::diversity(x, index = "invsimpson"))
}
individuales <- do.call(rbind, individuales)
# En funciones se promedia el índice calculado por MAG, con igual peso por genoma.
# NO se suman genes de 1, 6, 6 y 4 MAGs como si fueran abundancias de las muestras.
diversidad <- aggregate(cbind(q1, q2) ~ Tipo + Tiempo_h, data = individuales, FUN = mean)
diversidad <- diversidad[order(match(diversidad$Tipo, names(matrices)), diversidad$Tiempo_h), ]
diversidad$n_perfiles <- as.integer(table(paste(individuales$Tipo, individuales$Tiempo_h))[paste(diversidad$Tipo, diversidad$Tiempo_h)])
write.table(individuales, "results/09_sintesis/02_diversidad_por_perfil.tsv", sep = "\t", row.names = FALSE, quote = FALSE)
write.table(diversidad, "results/09_sintesis/02_diversidad_resumen.tsv", sep = "\t", row.names = FALSE, quote = FALSE)
largo <- rbind(data.frame(diversidad[, c("Tipo", "Tiempo_h", "n_perfiles")], Indice = "q1 · Exponencial de Shannon", Valor = diversidad$q1),
               data.frame(diversidad[, c("Tipo", "Tiempo_h", "n_perfiles")], Indice = "q2 · Inverso de Simpson", Valor = diversidad$q2))
largo$Z <- ave(largo$Valor, interaction(largo$Tipo, largo$Indice), FUN = function(x) as.numeric(scale(x)))
largo$Tipo <- factor(largo$Tipo, levels = names(matrices))
write.table(largo, "results/09_sintesis/02_diversidad_z.tsv", sep = "\t", row.names = FALSE, quote = FALSE)
colores <- colores_datos
nombres <- c(Kraken = "Kraken · géneros bacterianos", Kaiju = "Kaiju · categorías clasificadas", Funciones = "Funciones · promedio por MAG")
paneles <- list()
for (tipo in names(matrices)) {
 for (indice in unique(largo$Indice)) {
  d <- largo[largo$Tipo == tipo & largo$Indice == indice, ]
  paneles[[paste(tipo, indice)]] <- ggplot(d, aes(Tiempo_h, Valor)) +
    geom_line(colour = colores[tipo], linewidth = 1) + geom_point(colour = colores[tipo], size = 3.5) +
    geom_text(aes(label = sprintf("%.2f", Valor)), vjust = -0.8, size = 4.4) +
    scale_x_continuous(breaks = horas, labels = etiquetas) +
    scale_y_continuous(limits = c(0, NA), expand = expansion(mult = c(0, 0.22))) +
    labs(title = nombres[tipo], subtitle = indice, x = NULL,
         y = if (tipo == "Funciones") "Funciones efectivas\npor MAG" else if (tipo == "Kraken") "Géneros efectivos" else "Categorías efectivas") +
    theme(plot.title = element_text(size = 17), axis.title.y = element_text(size = 13))
 }
}
for (indice in unique(largo$Indice)) {
 d <- largo[largo$Indice == indice, ]
 paneles[[paste("Z", indice)]] <- ggplot(d, aes(Tiempo_h, Z, colour = Tipo, shape = Tipo)) +
   geom_hline(yintercept = 0, colour = "grey70", linetype = 2) +
   geom_line(linewidth = 1) + geom_point(size = 3.5) +
   scale_colour_manual(values = colores) + scale_shape_manual(values = c(Kraken = 16, Kaiju = 17, Funciones = 15)) +
   scale_x_continuous(breaks = horas, labels = etiquetas) + scale_y_continuous(limits = c(-1.7, 1.7), breaks = -1:1) +
   labs(title = "Comparar la forma de los cambios", subtitle = paste(indice, "· z entre cuatro tiempos"),
        x = "Tiempo de fermentación", y = "z del índice", colour = NULL, shape = NULL) +
   theme(plot.title = element_text(size = 17), axis.title.y = element_text(size = 13))
}
fig2 <- wrap_plots(paneles, ncol = 2, guides = "collect") +
 plot_annotation(title = "02 · ¿Cómo cambia el reparto de taxones y funciones?",
 subtitle = "Arriba: valores originales, con unidades y escalas distintas. Abajo: z para comparar tendencias, no magnitudes.",
 caption = "Funciones: media del índice por MAG; 1, 6, 6 y 4 genomas por etapa. No es diversidad funcional de toda la comunidad.\nUn perfil de lecturas por tiempo; no se estiman intervalos de incertidumbre. No se calcula diversidad sobre CLR.")
ggsave("results/09_sintesis/02_diversidad.pdf", fig2, width = 17, height = 17, device = cairo_pdf)
ggsave("results/09_sintesis/02_diversidad.png", fig2, width = 17, height = 17, dpi = 300, device = "png", type = "cairo")
print(diversidad)

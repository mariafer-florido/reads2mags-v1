source("scripts/09_sintesis/00_preparar.R", encoding = "UTF-8")
library(ape)
x <- as.matrix(read.delim("data/09_sintesis/MAG_KO_conteos.tsv", row.names = 1, check.names = FALSE))
meta <- read.delim("data/09_sintesis/MAG_metadata.tsv", check.names = FALSE)
sel <- read.delim("data/09_sintesis/funciones_pianka_seleccionadas.tsv", check.names = FALSE)
stopifnot(is.numeric(x), all(is.finite(x)), all(x >= 0),
 !anyDuplicated(rownames(x)), !anyDuplicated(meta$MAG), setequal(rownames(x), meta$MAG),
 !anyDuplicated(sel$KO), all(sel$KO %in% colnames(x)))
# Analisis principal: las siete funciones del arbol. El repertorio completo es referencia.
conjuntos <- list(Seleccionadas = x[, sel$KO, drop = FALSE], Todas = x)
matrices <- list()
for (nombre in names(conjuntos)) {
 m <- conjuntos[[nombre]]
 stopifnot(all(rowSums(m) > 0))
 p_mag <- vegan::decostand(m, method = "total", MARGIN = 1)
 d <- vegan::designdist(p_mag, method = "1-J/sqrt(A*B)", terms = "quadratic", name = "1 - Pianka")
 matrices[[nombre]] <- 1 - as.matrix(d)
 write.table(matrices[[nombre]], paste0("results/09_sintesis/08_pianka_", nombre, ".tsv"), sep = "\t", col.names = NA, quote = FALSE)
}
write.table(conjuntos$Seleccionadas, "results/09_sintesis/08_conteos_funciones_seleccionadas.tsv", sep = "\t", col.names = NA, quote = FALSE)
indices <- which(upper.tri(matrices$Seleccionadas), arr.ind = TRUE)
pares <- data.frame(MAG_A = rownames(x)[indices[, 1]], MAG_B = rownames(x)[indices[, 2]],
 Pianka = matrices$Seleccionadas[indices])
pares$Genero_A <- meta$Genus[match(pares$MAG_A, meta$MAG)]
pares$Genero_B <- meta$Genus[match(pares$MAG_B, meta$MAG)]
pares$Completitud_A <- meta$Completeness[match(pares$MAG_A, meta$MAG)]
pares$Completitud_B <- meta$Completeness[match(pares$MAG_B, meta$MAG)]
write.table(pares, "results/09_sintesis/08_pianka_pares_seleccionados.tsv", sep = "\t", row.names = FALSE, quote = FALSE)
# Orden filogenetico para consultar junto al arbol; no se agrupa por el valor de Pianka.
arbol <- ape::ladderize(ape::root(ape::read.tree("data/09_sintesis/bac120_17mags.treefile"), outgroup = "MAG07_09h", resolve.root = TRUE))
arbol <- ape::reorder.phylo(arbol, order = "cladewise")
orden <- rev(arbol$tip.label[arbol$edge[arbol$edge[, 2] <= ape::Ntip(arbol), 2]])
etiquetas_y <- setNames(paste(sub("_.*", "", meta$MAG), meta$Genus), meta$MAG)
etiquetas_x <- setNames(sub("_.*", "", meta$MAG), meta$MAG)
for (nombre in names(matrices)) {
 m <- matrices[[nombre]][orden, orden]; m[upper.tri(m, diag = TRUE)] <- NA
 d <- as.data.frame(as.table(m), stringsAsFactors = FALSE); names(d) <- c("MAG_A", "MAG_B", "Pianka")
 d <- d[is.finite(d$Pianka), ]
 d$MAG_A <- factor(d$MAG_A, levels = rev(orden)); d$MAG_B <- factor(d$MAG_B, levels = orden)
 fig8 <- ggplot(d, aes(MAG_B, MAG_A, fill = Pianka)) +
  geom_tile(colour = "white", linewidth = .4) +
  geom_text(aes(label = sprintf("%.2f", Pianka), colour = Pianka < .55), size = 4.6, show.legend = FALSE) +
  scale_colour_manual(values = c("TRUE" = "white", "FALSE" = "#173B4D"), guide = "none") +
  scale_fill_viridis_c(option = "C", limits = c(0, 1), breaks = c(0, .25, .5, .75, 1), name = "Pianka",
   guide = guide_colourbar(barwidth = grid::unit(9, "cm"), barheight = grid::unit(.5, "cm"), title.position = "top")) +
  scale_x_discrete(drop = FALSE, labels = etiquetas_x) +
  scale_y_discrete(drop = FALSE, labels = etiquetas_y) + coord_fixed() +
  labs(title = if (nombre == "Seleccionadas") "08 · Similitud de capacidades genéticas seleccionadas" else "Referencia · Similitud del repertorio anotado completo",
   subtitle = if (nombre == "Seleccionadas") "Siete funciones: carbohidratos, lactato, acetato y unión a péptidos. Mismo orden que el árbol." else "Todas las funciones anotadas; incluye metabolismo y maquinaria celular general.",
   x = "MAG comparado", y = NULL,
   caption = "Pianka compara proporciones de anotaciones gen–KO: 0 = sin coincidencia; 1 = perfiles proporcionales idénticos.\nNo mide consumo, competencia ni actividad. Los ceros de entrada indican no recuperación; influyen completitud y asignaciones múltiples.") +
  theme(panel.grid = element_blank(), axis.text.x = element_text(angle = 55, hjust = 1, size = 15),
   axis.text.y = element_text(size = 15), plot.title = element_text(size = 22), plot.subtitle = element_text(size = 14),
   plot.caption = element_text(size = 12), legend.position = "bottom")
 archivo <- if (nombre == "Seleccionadas") "08_pianka_funcional" else "08_pianka_repertorio_completo"
 ggsave(paste0("results/09_sintesis/", archivo, ".pdf"), fig8, width = 17, height = 14, device = cairo_pdf)
 ggsave(paste0("results/09_sintesis/", archivo, ".png"), fig8, width = 17, height = 14, dpi = 300, type = "cairo")
}
print(pares[paste(pares$MAG_A, pares$MAG_B, sep = "|") %in% c("MAG11_24h|MAG17_48h", "MAG08_24h|MAG16_48h", "MAG06_09h|MAG07_09h"), ], row.names = FALSE)

source("scripts/09_sintesis/00_preparar.R", encoding = "UTF-8")
library(ape)
# Reutilizar el arbol IQ-TREE de la seccion 07; no estimar otro arbol.
arbol <- ape::read.tree("data/09_sintesis/bac120_17mags.treefile")
meta <- read.delim("data/09_sintesis/MAG_metadata.tsv", check.names = FALSE)
hits <- read.delim("trazabilidad/09_sintesis/09_KO_aceptados_genes.tsv", check.names = FALSE)
stopifnot(!anyDuplicated(meta$MAG), setequal(arbol$tip.label, meta$MAG), setequal(unique(hits$MAG), meta$MAG))
# Mismo grupo externo que en la practica; la raiz no es una fecha.
arbol <- ape::root(arbol, outgroup = "MAG07_09h", resolve.root = TRUE, edgelabel = TRUE)
arbol <- ape::ladderize(arbol)
meta <- meta[match(arbol$tip.label, meta$MAG), ]
funciones <- c(K00925 = "Acetato quinasa", K01176 = "Alfa-amilasa", K01200 = "Pululanasa",
               K00016 = "L-lactato DH", K03778 = "D-lactato DH",
               K02035 = "Unión a péptidos/níquel", K15580 = "Unión a oligopéptidos")
# Estados de evidencia, no cantidades: no recuperado / anotado / asignacion multiple.
estado <- matrix("No recuperado", nrow = nrow(meta), ncol = length(funciones), dimnames = list(meta$MAG, names(funciones)))
for (m in rownames(estado)) for (ko in colnames(estado)) {
 h <- hits[hits$MAG == m & hits$KO == ko, ]
 if (nrow(h)) estado[m, ko] <- if (any(h$n_KO_for_gene == 1)) "Anotado" else "Asignación múltiple"
}
write.table(estado, "results/09_sintesis/07_funciones_por_MAG.tsv", sep = "\t", col.names = NA, quote = FALSE)
write.table(data.frame(MAG = meta$MAG, Genero = meta$Genus, Tiempo_h = meta$Tiempo_h,
                       Completitud = meta$Completeness), "results/09_sintesis/07_etiquetas_arbol.tsv", sep = "\t", row.names = FALSE, quote = FALSE)
write.table(data.frame(Nodo = seq_along(arbol$node.label) + length(arbol$tip.label),
                       SHaLRT_UFBoot = arbol$node.label), "results/09_sintesis/07_soportes_arbol.tsv", sep = "\t", row.names = FALSE, quote = FALSE)
write.table(ape::cophenetic.phylo(arbol), "results/09_sintesis/07_distancias_filogeneticas.tsv", sep = "\t", col.names = NA, quote = FALSE)
# Solo las etiquetas graficas cambian; las uniones anteriores usaron el MAG completo.
etiquetas_arbol <- paste(meta$MAG, meta$Genus, sprintf("[%.1f%%]", meta$Completeness))
grafico_arbol <- arbol; grafico_arbol$tip.label <- etiquetas_arbol
rownames(estado) <- etiquetas_arbol
# Contar MAGs con evidencia recuperada, sin equiparar no recuperado con ausencia.
n_portadores <- colSums(estado != "No recuperado")
resumen_funciones <- data.frame(KO = names(funciones), Funcion = unname(funciones),
  MAGs_con_anotacion = as.integer(n_portadores),
  Asignacion_unica = as.integer(colSums(estado == "Anotado")),
  Solo_multiple = as.integer(colSums(estado == "Asignación múltiple")),
  No_recuperado = as.integer(colSums(estado == "No recuperado")), MAGs_evaluados = nrow(estado))
write.table(resumen_funciones, "results/09_sintesis/07_resumen_funciones.tsv", sep = "\t", row.names = FALSE, quote = FALSE)
colnames(estado) <- paste0(c("Acetato\nquinasa", "Alfa-\namilasa", "Pululanasa", "L-lactato\nDH", "D-lactato\nDH", "Unión a\npéptidos/\nníquel", "Unión a\noligopéptidos"), "\n", n_portadores, "/17")
# Funciones oficiales de ape alinean automaticamente la matriz por nombre de punta.
# La funcion de color solo fija la paleta, no calcula una estadistica nueva.
for (formato in c("pdf", "png")) {
 archivo <- paste0("results/09_sintesis/07_filogenia_funciones.", formato)
 if (formato == "pdf") cairo_pdf(archivo, width = 21, height = 12, pointsize = 16)
 else png(archivo, width = 21, height = 12, units = "in", res = 300, type = "cairo", pointsize = 16)
 par(mar = c(7, 1, 7, 1), xpd = NA, family = "sans")
 profundidad <- max(ape::node.depth.edgelength(grafico_arbol))
 ape::plot.phylo(grafico_arbol, align.tip.label = TRUE, underscore = TRUE, font = 1, cex = 0.85, label.offset = 0.05,
   tip.color = colores_h[as.character(meta$Tiempo_h)], edge.color = "#50616B", edge.width = 1.5,
   x.lim = c(0, profundidad + 6), y.lim = c(0, 18))
 par(cex = .85)
 ape::phydataplot(estado, grafico_arbol, style = "mosaic", offset = 2.3, width = .48,
    legend = "none", funcol = function(n) colores_estado, border = "white", lwd = 2)
 par(cex = 1)
 # Mostrar el nodo de menor soporte; los valores completos se guardan en TSV.
 bajo <- which(arbol$node.label == "87.5/80")
 if (length(bajo)) ape::nodelabels(arbol$node.label[bajo], node = bajo + length(arbol$tip.label),
    frame = "none", cex = .8, adj = c(1, -.6), col = "#9756A5")
 ape::add.scale.bar(x = 0, y = .15, length = .5, lwd = 2, cex = .8)
 title(main = "07 · Parentesco, origen y capacidades genéticas de los MAGs", line = 4, adj = 0, cex.main = 1.3, col.main = "#173B4D")
 mtext("Columnas: funciones y MAGs con anotación / 17. Filas: MAGs ordenados por el árbol; no por tiempo.", side = 3, line = 2.3, adj = 0, cex = .85)
 legend("bottomleft", inset = c(0, -.1), legend = paste(horas, "h"), text.col = colores_h,
    bty = "n", horiz = TRUE, cex = .85, title = "Origen del MAG")
 legend("bottomright", inset = c(.02, -.1), legend = names(colores_estado), fill = colores_estado,
    border = NA, bty = "n", horiz = TRUE, cex = .85, title = "Evidencia funcional")
 mtext("Ramas: sustituciones por sitio, no horas. Soporte mostrado: SH-aLRT/UFBoot del árbol original. Color del nombre: origen; corchetes: completitud. Gris: no recuperado, no ausencia. DH: deshidrogenasa.",
    side = 1, line = 5.7, adj = 0, cex = .78)
 dev.off()
}

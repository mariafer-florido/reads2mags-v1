source("scripts/09_sintesis/00_preparar.R", encoding = "UTF-8")

# FIGURA 1. Los 12 generos con mayor porcentaje medio + Lactobacillus,
# que se incluye explicitamente para examinar su aumento tardio.
top <- unique(c(order(rowMeans(porcentaje), decreasing = TRUE)[1:12],
                which(tabla$name == "Lactobacillus")))
barras <- rbind(porcentaje[top, , drop = FALSE],
                colSums(porcentaje) - colSums(porcentaje[top, , drop = FALSE]),
                100 - colSums(porcentaje))
rownames(barras) <- c(tabla$name[top], "Otros géneros bacterianos", "Sin asignación a género bacteriano")
perfil <- data.frame(Grupo = rep(rownames(barras), times = 4),
                     Tiempo = factor(rep(etiquetas, each = nrow(barras)), levels = etiquetas),
                     Porcentaje = as.vector(barras))
perfil$Grupo <- factor(perfil$Grupo, levels = rownames(barras))
paleta <- setNames(c(hcl.colors(length(top), "Dark 3"), "#A8BFC3", "#E6E9EC"), rownames(barras))
fig1 <- ggplot(perfil, aes(Tiempo, Porcentaje, fill = Grupo)) +
  geom_col(width = 0.66, position = position_stack(reverse = TRUE)) +
  scale_fill_manual(values = paleta) +
  scale_y_continuous(limits = c(0, 100), expand = expansion(mult = c(0, 0.02))) +
  labs(title = "01 · Composición bacteriana durante la fermentación",
       subtitle = "Kraken · porcentaje calculado sobre el total de fragmentos de cada muestra.",
       x = "Tiempo de fermentación", y = "% del total de fragmentos", fill = NULL,
       caption = "Gris: sin asignación a un género bacteriano. Un perfil por tiempo.\nLos porcentajes representan fragmentos; no miden biomasa ni crecimiento absoluto.") +
  guides(fill = guide_legend(ncol = 3)) +
  theme(panel.grid.major.x = element_blank(), legend.text = element_text(size = 13))
ggsave("results/09_sintesis/01_composicion.pdf", fig1, width = 13, height = 8.5, device = cairo_pdf)

ggsave("results/09_sintesis/01_composicion.png", fig1, device = "png", type = "cairo", width = 13, height = 8.5, dpi = 300)
writeLines(capture.output(sessionInfo()), "results/09_sintesis/sessionInfo.txt")

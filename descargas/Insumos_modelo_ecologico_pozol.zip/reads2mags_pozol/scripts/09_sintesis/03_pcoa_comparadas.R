source("scripts/09_sintesis/00_perfiles_clr.R", encoding = "UTF-8")
# Una PCoA por tipo. Mismo metodo; cada tipo conserva su propio espacio.
# Euclidiana sobre CLR: no requiere correccion de Lingoes.
graficos <- list()
estadisticos <- list()
for (tipo in names(perfiles)) {
  ord <- wcmdscale(dist(perfiles[[tipo]]), k = 2, eig = TRUE, add = FALSE)
  inercia <- 100 * ord$eig / sum(ord$eig[ord$eig > 0])
  xy <- data.frame(Tiempo_h = horas, Tiempo = factor(etiquetas, levels = etiquetas),
                   Eje1 = ord$points[, 1], Eje2 = ord$points[, 2])
  # Signo arbitrario: fijarlo no altera distancias ni autovalores.
  if (xy$Eje1[1] > 0) xy$Eje1 <- -xy$Eje1
  if (xy$Eje2[2] < 0) xy$Eje2 <- -xy$Eje2
  xy$Etiqueta <- etiquetas
  if (tipo == "Funciones") xy$Etiqueta <- paste0(etiquetas, " (", as.integer(n_mag), ifelse(n_mag == 1, " MAG)", " MAGs)"))
  estadisticos[[tipo]] <- data.frame(Tipo = tipo, Eje = seq_along(ord$eig), Autovalor = ord$eig, Inercia_porcentaje = inercia)
  write.table(xy, paste0("results/09_sintesis/03_PCoA_", tipo, ".tsv"), sep = "\t", row.names = FALSE, quote = FALSE)
  graficos[[tipo]] <- ggplot(xy, aes(Eje1, Eje2)) +
    geom_path(aes(group = 1), colour = "#8B9CA3", linewidth = 0.8) +
    geom_point(aes(colour = Tiempo), size = 4.5, show.legend = FALSE) +
    geom_text_repel(aes(label = Etiqueta), seed = 17, size = 4.5,
                    max.overlaps = Inf, max.iter = 10000, max.time = 30,
                    box.padding = 0.5, min.segment.length = 0) +
    scale_colour_manual(values = colores_tiempo) +
    scale_x_continuous(expand = expansion(mult = 0.22)) +
    scale_y_continuous(expand = expansion(mult = 0.25)) + coord_fixed(ratio = 1) +
    labs(title = titulos[[tipo]], subtitle = sprintf("Dos ejes: %.1f%% de la inercia", sum(inercia[1:2])),
         x = sprintf("PCoA 1 (%.1f%%)", inercia[1]), y = sprintf("PCoA 2 (%.1f%%)", inercia[2])) +
    theme(plot.title = element_text(size = 19), plot.subtitle = element_text(size = 14))
}
estadisticos <- do.call(rbind, estadisticos)
write.table(estadisticos, "results/09_sintesis/03_PCoA_inercia.tsv", sep = "\t", row.names = FALSE, quote = FALSE)
fig4 <- wrap_plots(graficos, ncol = 3) +
  plot_annotation(title = "03 · Tres perspectivas del cambio durante la fermentación",
                  subtitle = "PCoA de Aitchison · CLR con pseudoconteo 0.5 · cada panel tiene sus propios ejes.",
                  caption = "Los puntos de lecturas son muestras; los de funciones son centros de los MAGs recuperados por etapa.\nLos porcentajes describen representación geométrica, no efecto del tiempo. Comparar patrones dentro de cada panel.")
ggsave("results/09_sintesis/03_pcoa_comparadas.pdf", fig4, width = 20, height = 8, device = cairo_pdf)
ggsave("results/09_sintesis/03_pcoa_comparadas.png", fig4, width = 20, height = 8, dpi = 300, device = "png", type = "cairo")
print(estadisticos)

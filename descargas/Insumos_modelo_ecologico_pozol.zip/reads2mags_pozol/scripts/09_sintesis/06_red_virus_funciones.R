source("scripts/09_sintesis/00_preparar.R", encoding = "UTF-8")
library(igraph)
# Red de evidencia genetica: nodos virales y funciones, no hospederos.
meta_v <- read.delim("data/09_sintesis/vOTU_metadata.tsv", check.names = FALSE)
sel <- read.delim("data/09_sintesis/funciones_virales_red.tsv", check.names = FALSE)
hits_v <- read.delim("trazabilidad/09_sintesis/14_genes_virales_representantes.tsv", check.names = FALSE)
stopifnot(!anyDuplicated(meta_v$vOTU), !anyDuplicated(sel$KO),
          setequal(unique(hits_v$vOTU), meta_v$vOTU))
# Solo genes de las secuencias representantes, con KO seleccionado.
evidencia <- unique(hits_v[hits_v$KO %in% sel$KO, c("vOTU", "secuencia", "protein", "KO")])
enlaces <- aggregate(protein ~ vOTU + KO, evidencia, function(x) length(unique(x)))
names(enlaces)[3] <- "Genes_anotados"
enlaces$Funcion <- sel$Funcion[match(enlaces$KO, sel$KO)]
enlaces$Proceso <- sel$Proceso[match(enlaces$KO, sel$KO)]
enlaces$from <- enlaces$vOTU; enlaces$to <- enlaces$KO
write.table(evidencia, "results/09_sintesis/06_evidencia_genes_virales.tsv", sep = "\t", row.names = FALSE, quote = FALSE)
write.table(enlaces, "results/09_sintesis/06_enlaces_virus_funcion.tsv", sep = "\t", row.names = FALSE, quote = FALSE)
nodos <- data.frame(name = c(meta_v$vOTU, sel$KO), Etiqueta = c(meta_v$vOTU, sel$Funcion),
                     type = c(rep(FALSE, nrow(meta_v)), rep(TRUE, nrow(sel))))
g <- igraph::graph_from_data_frame(enlaces[, c("from", "to")], directed = FALSE, vertices = nodos)
stopifnot(igraph::is_bipartite(g))
pos <- igraph::layout_as_bipartite(g, types = igraph::V(g)$type)
nodos <- igraph::as_data_frame(g, what = "vertices")
nodos$x <- as.numeric(nodos$type); nodos$y <- pos[, 1]
nodos$x_texto <- nodos$x + ifelse(nodos$type, .03, -.03)
nodos$ajuste <- ifelse(nodos$type, 0, 1)
nodos$Grupo <- ifelse(nodos$type, "Función anotada", "Virus del catálogo")
nodos$Etiqueta <- vapply(nodos$Etiqueta, function(x) paste(strwrap(x, width = 36), collapse = "\n"), character(1))
enlaces$x <- nodos$x[match(enlaces$from, nodos$name)]
enlaces$y <- nodos$y[match(enlaces$from, nodos$name)]
enlaces$xend <- nodos$x[match(enlaces$to, nodos$name)]
enlaces$yend <- nodos$y[match(enlaces$to, nodos$name)]
fig6 <- ggplot() +
 geom_segment(data = enlaces, aes(x, y, xend = xend, yend = yend, colour = Proceso), linewidth = .8, alpha = .58) +
 geom_point(data = nodos, aes(x, y, shape = Grupo), size = 4.4, fill = "white", colour = "#173B4D", stroke = 1.2) +
 geom_text(data = nodos, aes(x_texto, y, label = Etiqueta, hjust = ajuste), size = 4.8, lineheight = .9, colour = "#173B4D") +
 scale_shape_manual(values = c("Virus del catálogo" = 24, "Función anotada" = 21)) +
 scale_colour_manual(values = c("Replicación del ADN" = "#395F9E", "Empaquetamiento del ADN" = "#087F8C", "Integración del ADN" = "#9756A5", "Pared bacteriana" = "#BE8125")) +
 coord_cartesian(xlim = c(-.28, 2.05), clip = "off") +
 labs(title = "06 · Conexiones entre virus y funciones anotadas",
      subtitle = sprintf("%d vOTUs · %d funciones seleccionadas · %d vínculos respaldados por anotaciones de genes.", nrow(meta_v), nrow(sel), nrow(enlaces)),
      caption = "Cada línea indica al menos un gen anotado en el representante del vOTU; el color resume su función.\nNo son correlaciones, abundancias, infecciones observadas ni asignaciones de hospedero.", colour = "Proceso asociado", shape = NULL) +
 theme_void(base_size = 16) + theme(legend.position = "bottom", legend.box = "vertical",
  plot.title = element_text(size = 22, face = "bold", colour = "#173B4D"), plot.caption = element_text(size = 12, hjust = 0, colour = "#50616B"),
  plot.subtitle = element_text(size = 14, colour = "#50616B"),
  plot.background = element_rect(fill = "white", colour = NA), plot.margin = margin(20, 25, 20, 25))
ggsave("results/09_sintesis/06_red_virus_funciones.pdf", fig6, width = 17, height = 12, device = cairo_pdf)
ggsave("results/09_sintesis/06_red_virus_funciones.png", fig6, width = 17, height = 12, dpi = 300, type = "cairo")
print(table(enlaces$Proceso))

# Ejecutar desde la raiz del proyecto. Cada bloque aparece completo en el HTML.
source("scripts/09_sintesis/01_composicion.R", encoding = "UTF-8")
source("scripts/09_sintesis/02_diversidad.R", encoding = "UTF-8")
source("scripts/09_sintesis/03_pcoa_comparadas.R", encoding = "UTF-8")
source("scripts/09_sintesis/04_aportes_clr.R", encoding = "UTF-8")
source("scripts/09_sintesis/05_trayectorias_z.R", encoding = "UTF-8")
# Red disponible con anotaciones reales de virus.
source("scripts/09_sintesis/06_red_virus_funciones.R", encoding = "UTF-8")
source("scripts/09_sintesis/07_filogenia_funciones.R", encoding = "UTF-8")
source("scripts/09_sintesis/08_pianka_funcional.R", encoding = "UTF-8")
writeLines(capture.output(sessionInfo()), "results/09_sintesis/sessionInfo.txt")

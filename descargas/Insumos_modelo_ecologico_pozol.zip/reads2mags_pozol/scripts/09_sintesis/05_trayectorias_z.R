source("scripts/09_sintesis/00_perfiles_clr.R", encoding = "UTF-8")
# Cuatro componentes por tipo con mayor suma de cambios CLR al cuadrado.
# z es POR COMPONENTE entre los cuatro tiempos, solo para visualizar.
# z=0: su media temporal; z=1: una desviacion estandar por encima.
mapa <- list()
for (tipo in names(perfiles)) {
  x <- perfiles[[tipo]]
  variacion <- colSums((x[2:4, , drop = FALSE] - x[1:3, , drop = FALSE])^2)
  elegidos <- names(head(sort(variacion, decreasing = TRUE), 4))
  z <- scale(x[, elegidos, drop = FALSE], center = TRUE, scale = TRUE)
  labs <- unname(nombres_perfiles[[tipo]][elegidos])
  mapa[[tipo]] <- data.frame(Tipo = tipo, Componente = rep(elegidos, each = 4),
                              Etiqueta = rep(labs, each = 4), Tiempo = rep(etiquetas, times = 4), Z = as.vector(z))
}
mapa <- do.call(rbind, mapa)
mapa$Tiempo <- factor(mapa$Tiempo, levels = etiquetas)
mapa$Tipo <- factor(mapa$Tipo, levels = names(perfiles))
write.table(mapa, "results/09_sintesis/05_trayectorias_z.tsv", sep = "\t", row.names = FALSE, quote = FALSE)
mapa$Etiqueta <- vapply(mapa$Etiqueta, function(s) paste(strwrap(s, width = 37), collapse = "\n"), character(1))
fig6 <- ggplot(mapa, aes(Tiempo, Etiqueta, fill = Z)) +
  geom_tile(colour = "white", linewidth = 1) +
  geom_text(aes(label = sprintf("%.1f", Z)), size = 4.5) +
  facet_wrap(~Tipo, ncol = 1, scales = "free_y", labeller = as_labeller(titulos)) +
  scale_fill_gradient2(low = "#76B3CF", mid = "white", high = "#D9A044", midpoint = 0,
                       limits = c(-2, 2), breaks = c(-2, -1, 0, 1, 2)) +
  labs(title = "05 · Comparar la forma de las trayectorias",
       subtitle = "CLR y después z por componente entre tiempos; cuatro componentes seleccionados por tipo de información.",
       x = "Tiempo de fermentación", y = NULL, fill = "z del CLR",
       caption = "Los colores comparan cada fila con SU propia media temporal; no comparan abundancias entre filas.\nLas funciones describen genomas recuperados, no su actividad ni su abundancia en la comunidad.") +
  theme(panel.grid = element_blank(), strip.text = element_text(size = 14, face = "bold"))
ggsave("results/09_sintesis/05_trayectorias_z.pdf", fig6, width = 16, height = 10, device = cairo_pdf)
ggsave("results/09_sintesis/05_trayectorias_z.png", fig6, width = 16, height = 10, dpi = 300, device = "png", type = "cairo")

source("scripts/09_sintesis/00_perfiles_clr.R", encoding = "UTF-8")
# d_Aitchison^2 = suma(delta_CLR^2). Se descompone d^2, no d.
# Porcentaje_j = 100 * delta_CLR_j^2 / sum(delta_CLR^2).
aportes <- list()
paneles <- list()
intervalos <- c("0–9 h", "9–24 h", "24–48 h")
for (tipo in names(perfiles)) {
  x <- perfiles[[tipo]]
  for (i in 1:3) {
    cambio <- x[i + 1, ] - x[i, ]
    a <- data.frame(Tipo = tipo, Intervalo = intervalos[i], Componente = names(cambio),
                    Nombre = unname(nombres_perfiles[[tipo]][names(cambio)]),
                    Delta_CLR = as.numeric(cambio), Aporte_pct_d2 = 100 * cambio^2 / sum(cambio^2))
    clave <- paste(tipo, i, sep = "_")
    aportes[[clave]] <- a
    top <- head(a[order(-a$Aporte_pct_d2), ], 3)
    top$Etiqueta <- top$Nombre
    top$Etiqueta <- vapply(top$Etiqueta, function(x) paste(strwrap(x, width = 28), collapse = "\n"), character(1))
    top$Etiqueta <- factor(top$Etiqueta, levels = rev(top$Etiqueta))
    top$Direccion <- factor(ifelse(top$Delta_CLR > 0, "Delta CLR > 0", "Delta CLR < 0"),
                             levels = c("Delta CLR > 0", "Delta CLR < 0"))
    paneles[[clave]] <- ggplot(top, aes(Aporte_pct_d2, Etiqueta, colour = Direccion)) +
      geom_point(size = 3.5, show.legend = TRUE) +
      geom_text(aes(label = sprintf("%.1f%%", Aporte_pct_d2)), hjust = -0.22, size = 4.4, colour = "#173B4D") +
      scale_x_log10(limits = c(0.1, 300), breaks = c(0.1, 1, 10, 100), labels = c("0.1", "1", "10", "100")) +
      scale_colour_manual(values = c("Delta CLR > 0" = "#087F8C", "Delta CLR < 0" = "#9756A5"),
                          limits = c("Delta CLR > 0", "Delta CLR < 0"), drop = FALSE) +
      labs(title = paste(tipo, intervalos[i], sep = " · "), x = "Aporte a d² (%) · eje log10", y = NULL, colour = NULL) +
      theme(plot.title = element_text(size = 17), axis.title.x = element_text(size = 13),
            axis.text = element_text(size = 13), panel.grid.major.y = element_blank())
  }
}
aportes <- do.call(rbind, aportes)
write.table(aportes, "results/09_sintesis/04_aportes_aitchison_todos.tsv", sep = "\t", row.names = FALSE, quote = FALSE)
fig5 <- wrap_plots(paneles, ncol = 3, guides = "collect") +
  plot_annotation(title = "04 · Componentes que más aportan al cambio composicional",
                  subtitle = "Tres mayores aportes por tipo de información e intervalo; denominador: TODOS los componentes. Eje horizontal logarítmico.",
                  caption = "Distancias iguales en x representan razones iguales: 0.1 → 1 → 10 → 100%. No es abundancia ni causalidad.\nFunciones: nombres explícitos; identificadores KO conservados en las tablas. Potencial genético, no actividad.")
ggsave("results/09_sintesis/04_contribuciones_comparadas.pdf", fig5, width = 20, height = 14, device = cairo_pdf)
ggsave("results/09_sintesis/04_contribuciones_comparadas.png", fig5, width = 20, height = 14, dpi = 300, device = "png", type = "cairo")

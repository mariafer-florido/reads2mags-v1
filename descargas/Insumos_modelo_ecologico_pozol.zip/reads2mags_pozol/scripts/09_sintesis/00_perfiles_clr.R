source("scripts/09_sintesis/00_preparar.R", encoding = "UTF-8")
library(ggrepel)
library(patchwork)
# Muestras o MAGs en filas; taxones o funciones en columnas.
kraken <- t(conteos)
kaiju_tab <- read.delim("data/09_sintesis/kaiju_matrix.tsv", check.names = FALSE)
kaiju_tab <- kaiju_tab[kaiju_tab$Taxonomy != "unclassified", ]
kaiju <- t(as.matrix(kaiju_tab[, c("0hrs", "9hrs", "24hrs", "48hrs")]))
colnames(kaiju) <- kaiju_tab$Taxonomy
rownames(kaiju) <- tiempos
mag <- as.matrix(read.delim("data/09_sintesis/MAG_KO_conteos.tsv", row.names = 1, check.names = FALSE))
# Clave MAG: unir metadatos por el ID completo, nunca por el orden de las filas.
meta_mag <- read.delim("data/09_sintesis/MAG_metadata.tsv", check.names = FALSE)
stopifnot(!anyDuplicated(meta_mag$MAG), setequal(rownames(mag), meta_mag$MAG))
meta_mag <- meta_mag[match(rownames(mag), meta_mag$MAG), ]
origen_mag <- meta_mag$Tiempo_h
# Filtros fijos, solo para las comparaciones CLR; no para diversidad.
kraken <- kraken[, colSums(kraken > 0) >= 3 & colSums(kraken) >= 50, drop = FALSE]
kaiju <- kaiju[, colSums(kaiju > 0) >= 3 & colSums(kaiju) >= 50, drop = FALSE]
mag <- mag[, colSums(mag > 0) >= 3, drop = FALSE]
# El pseudoconteo se suma a TODOS los conteos antes del logaritmo natural.
clr_kraken <- vegan::decostand(kraken, method = "clr", pseudocount = 0.5)
clr_kaiju <- vegan::decostand(kaiju, method = "clr", pseudocount = 0.5)
clr_mag <- vegan::decostand(mag, method = "clr", pseudocount = 0.5)
n_mag <- table(factor(origen_mag, levels = horas))
clr_funciones <- rowsum(clr_mag, group = factor(origen_mag, levels = horas))
clr_funciones <- sweep(clr_funciones, 1, as.numeric(n_mag), "/")
rownames(clr_funciones) <- tiempos
# Funciones: centro de los MAGs recuperados, con igual peso por MAG.
# No representa abundancia de funciones en la muestra completa.
perfiles <- list(Kraken = clr_kraken, Kaiju = clr_kaiju, Funciones = clr_funciones)
titulos <- c(Kraken = "Kraken · géneros bacterianos", Kaiju = "Kaiju · entradas taxonómicas",
             Funciones = "Funciones · catálogo de MAGs")
kd <- read.delim("data/09_sintesis/KO_definiciones.tsv", check.names = FALSE)
kd <- kd[!duplicated(kd$KO), ]
trad <- read.delim("data/09_sintesis/nombres_funciones.tsv", check.names = FALSE)
# La clave KO se conserva para unir. Solo cambia el texto de las figuras.
kd$Nombre_figura <- kd$definition
idx <- match(trad$KO, kd$KO)
stopifnot(!anyNA(idx), !anyDuplicated(trad$KO))
kd$Nombre_figura[idx] <- trad$Nombre_figura
nombres_perfiles <- list(
  Kraken = setNames(tabla$name, as.character(tabla$taxid)),
  Kaiju = setNames(sub(".*;", "", sub(";+$", "", kaiju_tab$Taxonomy)), kaiju_tab$Taxonomy),
  Funciones = setNames(kd$Nombre_figura, kd$KO))
auditoria <- data.frame(Tipo = names(perfiles), Componentes = vapply(perfiles, ncol, integer(1)),
                       Perfiles = 4L, Pseudoconteo = 0.5)
write.table(auditoria, "results/09_sintesis/00_auditoria_CLR.tsv", sep = "\t", row.names = FALSE, quote = FALSE)
write.table(data.frame(Tiempo_h = horas, MAGs_recuperados = as.integer(n_mag)),
            "results/09_sintesis/00_MAGs_por_origen.tsv", sep = "\t", row.names = FALSE, quote = FALSE)
for (tipo in names(perfiles)) {
  write.table(perfiles[[tipo]], paste0("results/09_sintesis/00_CLR_", tipo, ".tsv"), sep = "\t", col.names = NA, quote = FALSE)
}

source("scripts/09_sintesis/00_perfiles_clr.R", encoding = "UTF-8")
library(igraph)
# Extension condicionada a conteos reales de fragmentos mapeados a los vOTUs.
# Filas: vOTU; columnas: 0, 9, 24, 48. No son tiempos de ensamblaje ni coberturas.
archivo_virus <- "data/09_sintesis/vOTU_conteos.tsv"
if (!file.exists(archivo_virus)) {
  message("Red pendiente: falta data/09_sintesis/vOTU_conteos.tsv. No se generan correlaciones ni figura.")
} else {
  virus_tab <- read.delim(archivo_virus, check.names = FALSE)
  virus_meta <- read.delim("data/09_sintesis/vOTU_metadata.tsv", check.names = FALSE)
  stopifnot(all(c("vOTU", tiempos) %in% names(virus_tab)),
            !anyDuplicated(virus_tab$vOTU), !anyDuplicated(virus_meta$vOTU),
            setequal(virus_tab$vOTU, virus_meta$vOTU))
  virus <- t(as.matrix(virus_tab[, tiempos]))
  colnames(virus) <- virus_tab$vOTU
  rownames(virus) <- tiempos
  stopifnot(is.numeric(virus), all(is.finite(virus)), all(virus >= 0),
            all(virus == floor(virus)), all(rowSums(virus) > 0))
  # Misma regla descriptiva de lecturas: >=3 tiempos y >=50 fragmentos en total.
  conservar <- colSums(virus > 0) >= 3 & colSums(virus) >= 50
  virus <- virus[, conservar, drop = FALSE]
  if (ncol(virus) < 2L) stop("Se necesitan al menos dos vOTUs elegibles para un perfil CLR.")
  clr_virus <- vegan::decostand(virus, method = "clr", pseudocount = 0.5)
  # Conservar el universo CLR al retirar columnas constantes solo para correlacion.
  variables <- apply(clr_virus, 2, sd) > 1e-10
  clr_virus <- clr_virus[, variables, drop = FALSE]
  if (!ncol(clr_virus)) stop("No hay trayectorias virales variables que correlacionar.")
  # Seleccion de dibujo: seis generos dominantes y dos candidatos lacticos.
  bact_ids <- unique(c(as.character(tabla$taxid[order(rowMeans(porcentaje), decreasing = TRUE)[1:6]]),
                       as.character(tabla$taxid[tabla$name %in% c("Lactobacillus", "Limosilactobacillus")])))
  bact_ids <- intersect(bact_ids, colnames(clr_kraken))
  bact_ids <- bact_ids[apply(clr_kraken[, bact_ids, drop = FALSE], 2, sd) > 1e-10]
  stopifnot(length(bact_ids) > 0, identical(rownames(clr_kraken), rownames(clr_virus)))
  # Cuatro tiempos alineados por nombre. r describe similitud temporal, no infeccion.
  r <- cor(clr_kraken[, bact_ids, drop = FALSE], clr_virus, method = "pearson")
  pares <- as.data.frame(as.table(r), stringsAsFactors = FALSE)
  names(pares) <- c("TaxID_bacteria", "vOTU", "r_CLR")
  pares$Bacteria <- unname(nombres_perfiles$Kraken[pares$TaxID_bacteria])
  pares$Taxonomia_viral <- virus_meta$lineage[match(pares$vOTU, virus_meta$vOTU)]
  pares$n_tiempos <- 4L
  write.table(pares, "results/09_sintesis/06_todas_correlaciones.tsv", sep = "\t", row.names = FALSE, quote = FALSE)
  # Corte visual fijo; NO es significancia ni criterio de hospedero.
  enlaces <- pares[abs(pares$r_CLR) >= 0.85, ]
  enlaces$from <- paste0("B_", enlaces$TaxID_bacteria)
  enlaces$to <- enlaces$vOTU
  nodos <- data.frame(name = c(paste0("B_", bact_ids), colnames(clr_virus)),
    Etiqueta = c(unname(nombres_perfiles$Kraken[bact_ids]), colnames(clr_virus)),
    type = c(rep(FALSE, length(bact_ids)), rep(TRUE, ncol(clr_virus))))
  g <- igraph::graph_from_data_frame(enlaces[, c("from", "to", "r_CLR")], directed = FALSE, vertices = nodos)
  pos <- igraph::layout_as_bipartite(g, types = igraph::V(g)$type)
  nodos <- igraph::as_data_frame(g, what = "vertices")
  nodos$x <- as.numeric(nodos$type); nodos$y <- pos[, 1]
  nodos$Grupo <- ifelse(nodos$type, "Virus (vOTUs)", "Géneros bacterianos")
  nodos$x_texto <- nodos$x + ifelse(nodos$type, 0.035, -0.035)
  nodos$ajuste <- ifelse(nodos$type, 0, 1)
  enlaces$x <- nodos$x[match(enlaces$from, nodos$name)]
  enlaces$y <- nodos$y[match(enlaces$from, nodos$name)]
  enlaces$xend <- nodos$x[match(enlaces$to, nodos$name)]
  enlaces$yend <- nodos$y[match(enlaces$to, nodos$name)]
  write.table(enlaces, "results/09_sintesis/06_enlaces_dibujados.tsv", sep = "\t", row.names = FALSE, quote = FALSE)
  fig6 <- ggplot() +
    geom_segment(data = enlaces, aes(x, y, xend = xend, yend = yend, colour = r_CLR), linewidth = 1.1, alpha = .65) +
    geom_point(data = nodos, aes(x, y, fill = Grupo, shape = Grupo), size = 4.5, colour = "#173B4D") +
    geom_text(data = nodos, aes(x_texto, y, label = Etiqueta, hjust = ajuste), size = 4.6, colour = "#173B4D") +
    scale_fill_manual(values = c("Géneros bacterianos" = "#A7CDD1", "Virus (vOTUs)" = "#D7B9DB")) +
    scale_shape_manual(values = c("Géneros bacterianos" = 21, "Virus (vOTUs)" = 24)) +
    scale_colour_gradient2(low = "#9756A5", mid = "white", high = "#087F8C", midpoint = 0,
                          limits = c(-1, 1), name = "r de Pearson (CLR)") +
    coord_cartesian(xlim = c(-.75, 1.65), clip = "off") +
    labs(title = "06 · Afinidad temporal entre bacterias y virus del catálogo",
         subtitle = sprintf("%d parejas evaluadas; %d enlaces con |r| ≥ 0.85; cuatro tiempos.", nrow(pares), nrow(enlaces)),
         caption = "Cada grupo tiene su referencia CLR. Sin valores p: las asociaciones son exploratorias.\nUna arista no demuestra infección, cooperación ni competencia; compartir una tendencia temporal puede producirla.") +
    theme_void(base_size = 16) + theme(legend.position = "bottom",
      plot.title = element_text(size = 22, face = "bold"), plot.subtitle = element_text(size = 14),
      plot.caption = element_text(size = 12, hjust = 0), plot.margin = margin(20, 24, 20, 24))
  ggsave("results/09_sintesis/06_red_bipartita.pdf", fig6, width = 16, height = 10, device = cairo_pdf)
  ggsave("results/09_sintesis/06_red_bipartita.png", fig6, width = 16, height = 10, dpi = 300, type = "cairo")
}

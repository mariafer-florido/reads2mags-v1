# Modelo ecológico integrado

Trabaja desde la raíz del proyecto:

```bash
cd "$HOME/curso_metagenomica_2026/bitacora/reads2mags_pozol"
mkdir -p results/09_sintesis outs
```

Consulta la práctica y abre el código de cada figura cuando quieras reproducirla:
https://mariafer-florido.github.io/reads2mags-v1/Modelo_ecologico_integrado.html
El enlace estará disponible cuando se publique la actualización.

- `data/09_sintesis/`: 15 tablas y árbol de entrada.
- `scripts/09_sintesis/`: código R completo; coincide con los bloques del HTML.
- `trazabilidad/09_sintesis/`: procedencia, calidad y anotaciones de respaldo.
- `resultados_referencia/09_sintesis/`: tablas numéricas y versiones de la ejecución docente.
- `results/09_sintesis/`: destino de los resultados que generes tú.

En el HTML, abre «Reproducir el análisis: preparar datos, paquetes y estilo».
El entorno del curso es `/data/env/qiime2`. Debe incluir R y los paquetes
ggplot2, vegan, ggrepel, patchwork, igraph y ape, con soporte Cairo.
Los análisis usan un hilo por proceso. No requieren descargar bases ni repetir
ensamblajes, anotaciones o filogenias; no instalan paquetes automáticamente.

La ejecución completa es opcional, después de estudiar los bloques:

```bash
conda activate /data/env/qiime2
OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 Rscript --vanilla scripts/09_sintesis/09_ejecutar_todo.R > outs/09_sintesis.log 2>&1
cat outs/09_sintesis.log
```

La red reproducible enlaza virus y funciones mediante genes anotados.
La extensión `06b_red_bacteria_virus_condicional.R` no se ejecuta en el flujo:
falta `vOTU_conteos.tsv` y no se ha inventado esa matriz.
El origen de un ensamblaje viral no es abundancia temporal ni prueba de hospedero.

Las tablas de referencia permiten comparar valores, sin exigir una apariencia
idéntica de fuentes entre sistemas. `sessionInfo.txt` documenta la ejecución
de referencia; cada ejecución completa guarda su propia información en results/.
